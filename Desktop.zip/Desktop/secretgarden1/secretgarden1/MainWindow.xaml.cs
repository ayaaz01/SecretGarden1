﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace secretgarden1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        string username = "a";
        string password = "a";
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string username1 = usernametextbox.Text;
            string password1 = passwordtextbox.Text;

            // Check if the entered username and password match the predefined values
            if (username1 == username && password1 == password)
            {
                // If the username and password match, open the landing window
                landingwindow obj = new landingwindow();
                this.Visibility = Visibility.Collapsed;
                obj.Show();
            }
            else
            {
                // If the username and password don't match, display an error message or handle it accordingly
                MessageBox.Show("Incorrect username or password. Please try again.");
            }
        }

    }
}
