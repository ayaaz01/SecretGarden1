﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace secretgarden1
{
    /// <summary>
    /// Interaction logic for landingwindow.xaml
    /// </summary>
    public partial class landingwindow : Window
    {
        public landingwindow()
        {
            InitializeComponent();
        }

        private void Button_Compose(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Sent(object sender, RoutedEventArgs e)
        {

        }

        private void Button_drafts(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Deleted(object sender, RoutedEventArgs e)
        {

        }

        private void Media_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("media resource");
        }

        private void Tips_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Tips resource");
        }

        private void Arts_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Arts resource");
        }

        private void Resources_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("more resource");
        }

        private void track_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("track pics");
        }

        private void swimming_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("swimming pics");
        }

        private void artcomp_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("art competition");
        }

        private void drama_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("more resource");
        }

        private void editprofile_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("edit profile");
        }
        private void security_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("security");
        }
        private void notifications_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("notificatioins");
        }
        private void settings_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("settings");
        }

    }
}
